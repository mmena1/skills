#!/usr/bin/env bash
# Usage: turn.sh <label> <session-uuid> <new|resume> <message>
set -u
S=/tmp/claude-0/-home-user-skills/6433f044-31a9-5c7a-9d13-b5d90ff3609b/scratchpad/gate131b
label=$1 sid=$2 kind=$3 msg=$4
. $S/nested-env.sh
cd $S/target
if [ "$kind" = new ]; then sflag=(--session-id "$sid"); else sflag=(--resume "$sid"); fi
date -u +%FT%TZ > $S/runs/$label.start
claude -p "$msg" "${sflag[@]}" --model claude-opus-5-5 --permission-mode auto --permission-prompts none \
  --output-format stream-json --verbose > $S/runs/$label.jsonl 2> $S/runs/$label.stderr
echo "exit=$?" > $S/runs/$label.exit
date -u +%FT%TZ >> $S/runs/$label.exit
