import json,sys
path=sys.argv[1]; full=len(sys.argv)>2
uses={}; order=[]
for l in open(path):
    m=json.loads(l)
    t=m.get("type")
    if t=="assistant":
        for c in m["message"]["content"]:
            if c.get("type")=="tool_use":
                uses[c["id"]]={"i":len(order),"name":c["name"],"input":c["input"],"sub":bool(m.get("parent_tool_use_id")),"res":None,"err":None}
                order.append(c["id"])
    elif t=="user":
        cont=m["message"].get("content")
        if isinstance(cont,list):
            for c in cont:
                if c.get("type")=="tool_result" and c["tool_use_id"] in uses:
                    r=c["content"]; r=r if isinstance(r,str) else "".join(x.get("text","") for x in r)
                    uses[c["tool_use_id"]]["res"]=r; uses[c["tool_use_id"]]["err"]=c.get("is_error")
    elif t=="result":
        print("RESULT denials=",m.get("permission_denials"),"is_error=",m.get("is_error"),"turns=",m.get("num_turns"))
for tid in order:
    u=uses[tid]; inp=u["input"]
    emitted=len(json.dumps(inp).encode())
    ret=len((u["res"] or "").encode())
    d=inp.get("command") or inp.get("file_path") or inp.get("description") or ""
    print(f'--- idx {u["i"]} {"sub" if u["sub"] else "coord"} {u["name"]} emitted={emitted}B returned={ret}B err={u["err"]}')
    if full or u["name"] in ("Write","Edit","Read"):
        if u["name"]=="Edit": print("  old_string:",repr(inp["old_string"])[:2000]); print("  new_string:",inp["new_string"][:6000])
        elif u["name"]=="Write": print("  file:",inp["file_path"]); print(inp["content"][:12000])
        else: print("  input:",json.dumps(inp)[:3000])
        print("  result:",(u["res"] or "")[:1500])
    else:
        print("  ",str(d)[:4000])
        print("   result:",(u["res"] or "")[:600].replace("\n"," | "))
