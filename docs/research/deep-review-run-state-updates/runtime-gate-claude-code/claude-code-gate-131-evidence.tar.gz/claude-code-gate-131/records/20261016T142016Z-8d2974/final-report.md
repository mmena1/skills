## Deep Review Results

Reviewed: commit range 32b5ba1^..32b5ba1 (mmena1/skills)
Base / reviewed head / current head: 2672c670e1699150bfc333cd2d2e1f751ae2e058 / 32b5ba1796db8f594f8ec721129c4ac3bbefdc65 / 32b5ba1796db8f594f8ec721129c4ac3bbefdc65
Publication: local only (only associated PR is #20, closed)
Scouts: `docs` → `deep-review-scout-docs`, `conventions` → `deep-review-scout-conventions`
Validation: run
Context snapshot: empty (no deep-review-context declarations at head)
Runtime: Claude Code 2.1.301 | Skill: deep-review c7f7bee | Validator agents: deep-review-validator-static

**Pipeline:** Hypotheses 6 → 6; Validation 2 Finding, 4 Disproved, 0 Unresolved
**Status:** complete
**PR review overlap:** skipped: no uniquely associated PR; Newly published not requested; Submission not requested; Read-back not requested

**Headline takeaway:** The new "Deep review" glossary entry points to a `deep-review` skill and glossary that do not exist at this commit.

### Runtime acceptance receipt

Enforcement: on Claude Code, scouts and static validators are read-only by instruction only. They have Read, Grep, Glob, and Bash, and Claude Code does not confine Bash to tool-list patterns, so the user's permission settings (auto mode) are the only mechanical boundary. No role sets permissionMode. No writable probe ran.

| Scenario | Status | Observed evidence |
|---|---|---|
| Zero hypotheses | NOT EXERCISED | 6 hypotheses emitted |
| Surviving hypotheses | PASS | H1 to H6 each received one independent static invocation |
| Capacity-bounded static validation | PASS | 6 hypotheses, 4-slot ceiling; H1 to H4 launched, H5 and H6 launched as slots freed; all completed |
| Multiple selected scouts | PASS | Both scouts dispatched in one message before waiting on either |
| Insufficient scout capacity | NOT EXERCISED | Strict preflight: 2 required, 20 available |
| Validator probes | NOT EXERCISED | No Needs probe outcomes; post-static baseline verified clean |
| Scout failure | NOT EXERCISED | Both scouts completed |
| Validator partial failure | NOT EXERCISED | All 6 static invocations completed |
| PR-review-overlap | NOT EXERCISED | No uniquely associated open PR |
| PR head change | NOT EXERCISED | Range pinned to commit SHAs |
| Cleanup | PASS | Only this run's worktree removed through `git worktree remove`; registration verified gone |

### Findings

#### Discuss

1. **"Deep review" glossary entry points to a skill and glossary that do not exist**: Finding | Action: discuss
   File: CONTEXT.md:21-23
   Comment scope: compact range
   Source anchor: CONTEXT.md:21-23 (new side)
   Anchor rationale: the complete added entry carries the present-tense claim
   Severity: low
   Evidence: The entry says the workflow is "owned by the `deep-review` skill" and its vocabulary "lives in that skill's glossary, not here." At 32b5ba1 there is no `skills/deep-review/`, no skill glossary, and no tracked definition of Hypothesis, Finding, or Unresolved. `docs/agents/domain.md` routes agents to `CONTEXT.md` for terms, and every other entry names a skill that exists.
   Why it matters: Anyone resolving the term at this commit is sent to a glossary that does not exist and is told the terms are "not here", until the #16 import lands.
   Discussion prompt: Should the entry say the skill is pending, for example "the workflow the `deep-review` skill will own once imported (#16)", or should it move to the import change that adds `skills/deep-review/`? Do not copy the deep-review vocabulary into `CONTEXT.md`.

2. **Glossary term "Native reviewer agent" and the ADR's "native agents" name one concept two ways**: Finding | Action: discuss
   File: CONTEXT.md:25-26
   Comment scope: compact range
   Source anchor: CONTEXT.md:25-26 (new side); related docs/adr/0001-skills-may-ship-native-agents.md:1,3
   Anchor rationale: the glossary is where the canonical term and `_Avoid_` line belong
   Severity: low
   Evidence: The only matches for "native ... agent" at head are the glossary term at CONTEXT.md:25 and the ADR's "native agents" (title) and "native agent definitions" (line 3). The definition at CONTEXT.md:26 is generic and never mentions review, and the ADR describes a generic mechanism. There is no `_Avoid_` line, although `skills/domain-modeling/CONTEXT-FORMAT.md:27` requires one when several words exist for a concept.
   Why it matters: The #16 implementation will name this concept in issues, AGENTS.md, check messages, and code. That author gets two candidate terms, and "reviewer" suggests a narrower mechanism than the one defined. A literal search for the ADR's wording misses the glossary entry.
   Discussion prompt: Which term is canonical? One option is renaming to **Native agent**, which matches the definition, the ADR title, and the filename, with `_Avoid_: native reviewer agent`. The other is keeping **Native reviewer agent**, using it in the ADR, reconciling the definition, and adding `_Avoid_: native agent`. An `_Avoid_` line alone does not settle the mismatch.

### Recommended Actions

- [ ] Discuss Finding #1 (CONTEXT.md "Deep review" entry wording or placement)
- [ ] Discuss Finding #2 (canonical term for native agents)

Disproved and not reported: ADR present-tense mechanism claims (ADRs record decisions), ADR-0001 number collision with `.agents/adr/` (numbering is scoped to `docs/adr/`), skill-scoped glossary convention (`codebase-design` precedent), and missing citations for harness capability (no citation convention).
