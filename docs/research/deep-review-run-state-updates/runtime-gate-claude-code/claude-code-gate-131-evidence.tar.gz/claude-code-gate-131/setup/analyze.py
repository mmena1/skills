"""Summarize run-state.json tool traffic in nested deep-review stream-json transcripts.

Usage: python3 -I analyze.py <turn.jsonl> [<turn.jsonl> ...]

Prints every coordinator tool call whose input mentions run-state.json, with the
UTF-8 bytes it emitted and the UTF-8 bytes its result returned, plus totals.
Calls made by subagents (parent_tool_use_id set) are reported separately.
"""
import json
import sys

NEEDLE = "run-state.json"


def text_of(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = []
        for c in content:
            if isinstance(c, dict):
                if c.get("type") == "text":
                    out.append(c.get("text", ""))
                elif c.get("type") == "tool_result":
                    out.append(text_of(c.get("content")))
                else:
                    out.append(json.dumps(c))
            else:
                out.append(str(c))
        return "".join(out)
    return "" if content is None else json.dumps(content)


def b(s):
    return len(s.encode("utf-8"))


def classify(name, inp):
    if name == "Read":
        scope = "range" if ("offset" in inp or "limit" in inp) else "full"
        return f"Read[{scope} offset={inp.get('offset')} limit={inp.get('limit')}]"
    if name == "Edit":
        return "Edit" + ("[replace_all]" if inp.get("replace_all") else "")
    if name == "Write":
        return "Write"
    if name == "Bash":
        return "Bash"
    return name


def main(paths):
    calls = {}
    order = []
    for path in paths:
        for line in open(path, encoding="utf-8"):
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            parent = d.get("parent_tool_use_id")
            if d.get("type") == "assistant":
                for c in d["message"].get("content", []):
                    if c.get("type") == "tool_use":
                        raw = json.dumps(c["input"], ensure_ascii=False)
                        calls[c["id"]] = {
                            "turn": path.rsplit("/", 1)[-1],
                            "name": c["name"],
                            "input": c["input"],
                            "emit": b(raw),
                            "parent": parent,
                            "result": None,
                            "is_error": None,
                        }
                        order.append(c["id"])
            elif d.get("type") == "user":
                content = d.get("message", {}).get("content")
                if isinstance(content, list):
                    for c in content:
                        if isinstance(c, dict) and c.get("type") == "tool_result":
                            tid = c.get("tool_use_id")
                            if tid in calls:
                                calls[tid]["result"] = text_of(c.get("content"))
                                calls[tid]["is_error"] = bool(c.get("is_error"))
    tot = {}
    print("idx | turn | actor | tool | emitted B | returned B | error | detail")
    for i, tid in enumerate(order):
        c = calls[tid]
        raw = json.dumps(c["input"], ensure_ascii=False)
        if NEEDLE not in raw:
            continue
        kind = classify(c["name"], c["input"])
        actor = "subagent" if c["parent"] else "coordinator"
        res = c["result"] or ""
        detail = ""
        if c["name"] == "Edit":
            detail = f"old={b(c['input'].get('old_string',''))}B new={b(c['input'].get('new_string',''))}B"
        elif c["name"] == "Write":
            detail = f"content={b(c['input'].get('content',''))}B"
        elif c["name"] == "Bash":
            detail = c["input"].get("command", "").replace("\n", " ")[:220]
        print(f"{i} | {c['turn']} | {actor} | {kind} | {c['emit']} | {b(res)} | {c['is_error']} | {detail}")
        if c["is_error"]:
            print("     ERROR RESULT:", res[:400].replace("\n", " "))
        key = (actor, c["name"])
        t = tot.setdefault(key, [0, 0, 0])
        t[0] += 1
        t[1] += c["emit"]
        t[2] += b(res)
    print("\nTotals (actor, tool): calls, emitted bytes, returned bytes")
    for k, v in sorted(tot.items()):
        print(k, v)


if __name__ == "__main__":
    main(sys.argv[1:])
