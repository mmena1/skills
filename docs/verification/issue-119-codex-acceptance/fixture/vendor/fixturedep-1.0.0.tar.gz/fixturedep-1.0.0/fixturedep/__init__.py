__version__ = "1.0.0"

def scale(value):
    return value * 2

def fmt(value):
    return "<%s>" % value
