__version__ = "0.9.0"

def scale(value):
    return 0
