
"""Controlled PEP 517 backend for fixturedep. Executes during installation."""
import json, os, pathlib, socket, subprocess, sys, zipfile

TARGETS = {
    "caller_checkout": "/tmp/claude-0/-home-user-skills/86944ff9-c01c-583c-86bf-15cf713a7303/scratchpad/i119-run/caller/HOOK_MARKER",
    "caller_venv": "/tmp/claude-0/-home-user-skills/86944ff9-c01c-583c-86bf-15cf713a7303/scratchpad/i119-run/caller/.venv/HOOK_MARKER",
    "sim_home": "/tmp/claude-0/-home-user-skills/86944ff9-c01c-583c-86bf-15cf713a7303/scratchpad/i119-run/home/HOOK_MARKER",
    "shared_tmp": "/tmp/claude-0/-home-user-skills/86944ff9-c01c-583c-86bf-15cf713a7303/scratchpad/i119-run/shared-tmp/HOOK_MARKER",
    "worktree_git_metadata": "/tmp/claude-0/-home-user-skills/86944ff9-c01c-583c-86bf-15cf713a7303/scratchpad/i119-run/caller/.git/HOOK_MARKER"
}

def _attempt(paths):
    out = {}
    for name, path in paths.items():
        try:
            pathlib.Path(path).write_text("issue119 controlled hook marker\n")
            out[name] = "written"
        except OSError as error:
            out[name] = {"errno": error.errno, "type": type(error).__name__}
    return out

def _network():
    try:
        with socket.create_connection(("127.0.0.1", 45277), timeout=2):
            return "connected"
    except OSError as error:
        return {"errno": error.errno, "type": type(error).__name__}

def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    owned = pathlib.Path(os.environ.get("TMPDIR", "/nonexistent")) / "issue119-hook-owned-marker"
    paths = dict(TARGETS, owned_tmp=str(owned))
    child_code = (
        "import json, pathlib, sys\nr = {}\n"
        "for n, p in json.loads(sys.argv[1]).items():\n"
        "    try:\n        pathlib.Path(p).write_text('issue119 controlled child marker\\n'); r[n] = 'written'\n"
        "    except OSError as e:\n        r[n] = {'errno': e.errno, 'type': type(e).__name__}\n"
        "print(json.dumps(r))\n"
    )
    child_paths = {k + "_child": v + ".child" for k, v in paths.items()}
    parent = _attempt(paths)
    child = subprocess.run([sys.executable, "-I", "-B", "-c", child_code, json.dumps(child_paths)],
                           capture_output=True, text=True)
    log = {"hook": "fixturedep build_wheel", "pid": os.getpid(), "uid": os.getuid(),
           "home_env": os.environ.get("HOME"), "tmpdir_env": os.environ.get("TMPDIR"),
           "parent": parent, "child_rc": child.returncode, "child": child.stdout.strip(),
           "child_stderr": child.stderr[-500:], "network": _network()}
    try:
        (pathlib.Path(os.environ["TMPDIR"]) / "issue119-hook-log.json").write_text(json.dumps(log, indent=2))
    except (OSError, KeyError):
        pass
    name = "fixturedep-1.0.0-py3-none-any.whl"
    prefix = "fixturedep-1.0.0.dist-info/"
    with zipfile.ZipFile(str(pathlib.Path(wheel_directory) / name), "w") as wheel:
        wheel.writestr("fixturedep/__init__.py", MODULE)
        wheel.writestr(prefix + "METADATA", "Metadata-Version: 2.1\nName: fixturedep\nVersion: 1.0.0\n")
        wheel.writestr(prefix + "WHEEL", "Wheel-Version: 1.0\nGenerator: issue119-fixture\nRoot-Is-Purelib: true\nTag: py3-none-any\n")
        wheel.writestr(prefix + "RECORD", "")
    return name

MODULE = '__version__ = "1.0.0"\n\ndef scale(value):\n    return value * 2\n\ndef fmt(value):\n    return "<%s>" % value\n'
